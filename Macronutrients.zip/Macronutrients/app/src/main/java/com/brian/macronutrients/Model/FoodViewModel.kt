package com.brian.macronutrients.Model

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.brian.macronutrients.MySql.Database

class FoodViewModel (private val context: Context) : ViewModel() {

    private val databaseService = Database(context)
    private val _foodData = MutableLiveData<Food>()
    val foodData: LiveData<Food>
        get() = _foodData

    init {
        fetchData()
    }

    fun fetchData():Food {
        return databaseService.record
    }


    fun fetchArrayList(): ArrayList<Food> {
        return ArrayList(databaseService.foodData ?: emptyList())
    }

    fun addFood(food: Food) {
        databaseService.addFood(food)
        fetchArrayList()
        fetchData()
    }
    fun updateFood(food: Food) {
        databaseService.updateFoodStatus(food)
        fetchArrayList()
        fetchData()
    }

    fun clearAllRecords() {
        databaseService.deleteAllRecords()
        fetchData()
    }
}
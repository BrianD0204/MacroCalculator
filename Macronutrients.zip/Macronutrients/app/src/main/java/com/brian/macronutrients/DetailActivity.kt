package com.brian.macronutrients

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.cardview.widget.CardView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.brian.macronutrients.DetailActivity.ArrayAdapter.ImageViewHoler
import com.brian.macronutrients.Model.Food
import com.brian.macronutrients.Model.FoodViewModel
import com.brian.macronutrients.Model.FoodViewModelFactory
import java.util.Locale


class DetailActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var search: EditText
    private lateinit var food_name: EditText
    private lateinit var food_fat: EditText
    private lateinit var food_carbs: EditText
    private lateinit var food_protein: EditText

    private lateinit var viewModel: FoodViewModel
    private var foodArrayList = ArrayList<Food>()
    private var foodList = ArrayList<Food>()
    private lateinit var arrayAdapter: ArrayAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        viewModel = ViewModelProvider(this, FoodViewModelFactory(this)).get(FoodViewModel::class.java)

        recyclerView = findViewById(R.id.recy)
        recyclerView.setLayoutManager(
            LinearLayoutManager(
                this,
                LinearLayoutManager.VERTICAL,
                false
            )
        )
        food_name = findViewById(R.id.food_name)
        food_fat = findViewById(R.id.food_fat)
        food_carbs = findViewById(R.id.food_carbs)
        food_protein = findViewById(R.id.food_protein)
        search = findViewById(R.id.search)
        foodRecord
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}
            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}
            override fun afterTextChanged(editable: Editable) {
                filter(editable.toString())
            }

            private fun filter(text: String) {
                val filterlist = ArrayList<Food>()
                for (item in foodArrayList) {
                    if (item.foodName!!.toLowerCase(Locale.getDefault()).contains(text.lowercase(Locale.getDefault()))) {
                        filterlist.add(item)
                    }
                }
                arrayAdapter!!.filteredList(filterlist)
            }
        })
    }

    fun saveRecord(view: View?) {
        if (food_name!!.getText().toString().isEmpty()) {
            food_name!!.error = "required"
        } else if (food_carbs!!.getText().toString().isEmpty()) {
            food_carbs!!.error = "required"
        } else if (food_protein!!.getText().toString().isEmpty()) {
            food_protein!!.error = "required"
        } else if (food_fat!!.getText().toString().isEmpty()) {
            food_fat!!.error = "required"
        } else {
            val food = Food(
                food_name!!.getText().toString(),
                food_fat!!.getText().toString(),
                food_carbs!!.getText().toString(),
                food_protein!!.getText().toString()
            )
            viewModel.addFood(food)
            food_carbs.setText("")
            food_protein.setText("")
            food_name.setText("")
            food_fat.setText("")
            foodRecord
        }
    }
    val foodRecord: Unit
        get() {
            foodArrayList.clear()
            foodArrayList=viewModel.fetchArrayList()
            arrayAdapter = ArrayAdapter()
            recyclerView!!.setAdapter(arrayAdapter)
        }

    inner class ArrayAdapter : RecyclerView.Adapter<ImageViewHoler>() {
        init {
            foodList = foodArrayList
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHoler {
            val v = LayoutInflater.from(this@DetailActivity)
                .inflate(R.layout.item_food, parent, false)
            return ImageViewHoler(v)
        }

        override fun onBindViewHolder(
            holder: ImageViewHoler,
            @SuppressLint("RecyclerView") position: Int
        ) {
            holder.food_name.setText(foodList[position].foodName)
            // Set OnClickListener for the cardView
            holder.cardView.setOnClickListener {
                val clickedFood = foodList[position]
                showConfirmationDialog(clickedFood)
            }
        }

        override fun getItemCount(): Int {
            return foodList.size
        }

        fun filteredList(filterlist: ArrayList<Food>) {
            foodList = filterlist
            notifyDataSetChanged()
        }

        inner class ImageViewHoler(itemView: View) : RecyclerView.ViewHolder(itemView) {
            var food_name: TextView
            var cardView: CardView

            init {
                food_name = itemView.findViewById(R.id.food_name)
                cardView = itemView.findViewById(R.id.cardView)
            }
        }
    }

    private fun applyDarkMode(darkModeEnabled: Boolean) {
        if (darkModeEnabled) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    fun finish(view: View?) {
        finish()
    }


    private fun showConfirmationDialog(food: Food) {


        val alertDialogBuilder = AlertDialog.Builder(this@DetailActivity)
        alertDialogBuilder.apply {
            setTitle("Confirmation")
            setMessage("Are you sure you want to add ?")
            setPositiveButton("Yes") { _, _ ->
                viewModel.updateFood(food)

            }
            setNegativeButton("No") { dialog, _ ->
                dialog.dismiss()
            }
        }
        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }
}
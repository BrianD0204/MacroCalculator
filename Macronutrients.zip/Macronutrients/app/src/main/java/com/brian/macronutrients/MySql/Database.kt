package com.brian.macronutrients.MySql

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast
import com.brian.macronutrients.Model.Food

class Database(var context: Context) : SQLiteOpenHelper(context, DBName, null, 1) {
    override fun onCreate(db: SQLiteDatabase) {

        db.execSQL(
            " create table " + TName + "(" + Col1 + " TEXT," + Col2 + " TEXT," + Col3 + " TEXT," + Col4 + " TEXT,"
                    + Col5 + " INTEGER PRIMARY KEY AUTOINCREMENT)"
        )
        db.execSQL(
            " create table " + TChartData + "(" + Col1 + " TEXT," + Col2 + " TEXT," + Col3 + " TEXT," + Col4 + " TEXT,"
                    + Col5 + " INTEGER PRIMARY KEY AUTOINCREMENT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS " + TName)
        db.execSQL("DROP TABLE IF EXISTS " + TChartData)
        onCreate(db)
    }

    fun addFood(food: Food) {
        val db = this.writableDatabase
        val cv = ContentValues()
        cv.put(Col1, food.foodName)
        cv.put(Col2, food.foodFat)
        cv.put(Col3, food.foodCarbs)
        cv.put(Col4, food.foodProtein)
        val result = db.insert(TName, null, cv)
        db.insert(TChartData, null, cv)
        if (result != -1L) {
            Toast.makeText(context, "food add successfully", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(context, "food not add successfully", Toast.LENGTH_LONG).show()
        }
        db.close()
    }

    fun updateFoodStatus(food: Food) {




        val db = this.writableDatabase

        var foodRecord: Food? = null
        val query = "SELECT * FROM $TChartData WHERE $Col1 = ?"
        val cursor = db.rawQuery(query, arrayOf(food.foodName))
        if (cursor.moveToFirst()) {

            foodRecord = Food(
                cursor.getString(0),
                cursor.getString(1),
                cursor.getString(2),
                cursor.getString(3),
                cursor.getInt(4).toString()
            )
        }
        if (foodRecord == null) {
            // If the food record doesn't exist, insert a new record
            val values = ContentValues().apply {
                put(Col1, food.foodName)
                put(Col2, food.foodFat)
                put(Col3, food.foodCarbs)
                put(Col4, food.foodProtein)
                // Assuming Col5 is the primary key or some unique identifier for the record
            }
            db.insert(TChartData, null, values)
        } else {
            // If the food record exists, update the record
            val foodCarbs = foodRecord.foodCarbs.toInt() + food.foodCarbs.toInt()
            val foodProtein = foodRecord.foodProtein.toInt() + food.foodProtein.toInt()
            val foodFat = foodRecord.foodFat.toInt() + food.foodFat.toInt()
            val cv = ContentValues().apply {
                put(Col2, foodFat.toString())
                put(Col3, foodCarbs.toString())
                put(Col4, foodProtein.toString())
            }
            db.update(TChartData, cv, "$Col1 = ?", arrayOf(food.foodName))
        }

        Toast.makeText(context, "food add successfully", Toast.LENGTH_LONG).show()
    }

    fun deleteAllRecords() {
        val db = this.writableDatabase
        db.delete(TChartData, null, null)
    }



    val foodData: ArrayList<Food>
        // get all food data from food table
        get() {
            val foodArrayList = ArrayList<Food>()
            val db = this.readableDatabase
            val cursor = db.query(TName, null, null, null, null, null, null)
            cursor.moveToFirst()
            while (!cursor.isAfterLast) {
                foodArrayList.add(
                    Food(
                        cursor.getString(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getInt(4).toString()
                    )
                )
                cursor.moveToNext()
            }
            return foodArrayList
        }
    val record: Food
        get() {
            var food: Food? = null
            var foodFat = 0
            var foodCarbs = 0
            var foodProtein = 0
            val db = this.readableDatabase
            val cursor = db.query(TChartData, null, null, null, null, null, null)
            cursor.moveToFirst()
            while (!cursor.isAfterLast) {
                foodFat = foodFat + cursor.getString(1).toInt()
                foodCarbs = foodCarbs + cursor.getString(2).toInt()
                foodProtein = foodProtein + cursor.getString(3).toInt()
                cursor.moveToNext()
            }
            food = Food(
                foodFat.toString() + "",
                foodCarbs.toString() + "",
                foodProtein.toString() + ""
            )
            return food
        }

    companion object {
        const val DBName = "Macros_Database"
        const val TName = "Food_Data"
        const val TChartData = "Food_Chart_Data"
        const val Col1 = "foodName"
        const val Col2 = "foodFat"
        const val Col3 = "foodCarbs"
        const val Col4 = "foodProtein"
        const val Col5 = "foodId"
    }
}

package com.brian.macronutrients

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import com.brian.macronutrients.Model.Food
import com.brian.macronutrients.Model.FoodViewModel
import com.brian.macronutrients.Model.FoodViewModelFactory
import org.eazegraph.lib.charts.PieChart
import org.eazegraph.lib.models.PieModel

class MainActivity : AppCompatActivity() {

    var food_fat: TextView? = null
    var food_carbs: TextView? = null
    var food_protein: TextView? = null
    var pieChart: PieChart? = null

    private lateinit var viewModel: FoodViewModel
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPreferences = getSharedPreferences("user_settings", MODE_PRIVATE)
        applyDarkMode(sharedPreferences.getBoolean("dark_mode", false))
        setContentView(R.layout.activity_main)

        viewModel = ViewModelProvider(this, FoodViewModelFactory(this)).get(FoodViewModel::class.java)
        pieChart = findViewById(R.id.piechart)
        food_fat = findViewById(R.id.food_fat)
        food_carbs = findViewById(R.id.food_carbs)
        food_protein = findViewById(R.id.food_protein)
    }

    override fun onStart() {
        super.onStart()
        val food = viewModel.fetchData()
        food_fat?.text = "${food.foodFat}g Fat"
        food_carbs?.text = "${food.foodCarbs}g Carbs"
        food_protein?.text = "${food.foodProtein}g Protein"
        showData(food)
    }

    fun showData(food: Food?) {
        food?.let {
            pieChart?.clearChart()
            pieChart?.addPieSlice(
                PieModel(
                    "Fat", it.foodFat.toInt().toFloat(),
                    Color.parseColor("#FFA726")
                )
            )
            pieChart?.addPieSlice(
                PieModel(
                    "Carbs", it.foodCarbs.toInt().toFloat(),
                    Color.parseColor("#66BB6A")
                )
            )
            pieChart?.addPieSlice(
                PieModel(
                    "Protein", it.foodProtein.toInt().toFloat(),
                    Color.parseColor("#EF5350")
                )
            )
            // To animate the pie chart
            pieChart?.startAnimation()
        }
    }

    fun addRecord(view: View?) {
        startActivity(Intent(this, DetailActivity::class.java))
    }

    fun clearFoodChart(view: View?) {
        pieChart!!.clearChart()
        food_fat!!.text = "0g Fat"
        food_carbs!!.text = "0g Carbs"
        food_protein!!.text = "0g Protein"
        pieChart!!.addPieSlice(
            PieModel(
                "Fat",
                0f,
                Color.parseColor("#FFA726")
            )
        )
        pieChart!!.addPieSlice(
            PieModel(
                "Carbs",
                0f,
                Color.parseColor("#66BB6A")
            )
        )
        pieChart!!.addPieSlice(
            PieModel(
                "Protein",
                0f,
                Color.parseColor("#EF5350")
            )
        )
        viewModel.clearAllRecords()
        pieChart!!.startAnimation()
    }

    fun openSettingScreen(view: View?) {
        startActivity(Intent(this, SettingActivity::class.java))
    }

    private fun applyDarkMode(darkModeEnabled: Boolean) {
        if (darkModeEnabled) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }
}

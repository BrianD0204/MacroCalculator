package com.brian.macronutrients.Model

class Food {
    @kotlin.jvm.JvmField
    var foodName: String? = null
    var foodFat: String
    var foodCarbs: String
    var foodProtein: String
    var foodId: String? = null

    constructor(
        foodName: String?,
        foodFat: String,
        foodCarbs: String,
        foodProtein: String,
        foodId: String?
    ) {
        this.foodName = foodName
        this.foodFat = foodFat
        this.foodCarbs = foodCarbs
        this.foodProtein = foodProtein
        this.foodId = foodId
    }

    constructor(foodFat: String, foodCarbs: String, foodProtein: String) {
        this.foodFat = foodFat
        this.foodCarbs = foodCarbs
        this.foodProtein = foodProtein
    }

    constructor(foodName: String?, foodFat: String, foodCarbs: String, foodProtein: String) {
        this.foodName = foodName
        this.foodFat = foodFat
        this.foodCarbs = foodCarbs
        this.foodProtein = foodProtein
    }
}
